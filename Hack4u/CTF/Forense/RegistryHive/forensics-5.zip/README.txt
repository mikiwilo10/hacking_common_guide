Análisis de Registro de Windows

Se ha exportado el registro de un equipo comprometido.
El atacante ocultó información en claves de registro aparentemente legítimas.

Encuentra los fragmentos y reconstruye la flag.

La flag está en formato H4U{...}
