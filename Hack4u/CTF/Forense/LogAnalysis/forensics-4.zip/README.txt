Análisis de Logs

El servidor web fue atacado. Analiza los logs de acceso y encuentra la flag.

La flag está en formato H4U{...}
