Análisis de Imagen de Disco

Un sospechoso formateó su disco antes de la intervención forense.
Se realizó una imagen bit a bit del disco.

Recupera los datos eliminados y encuentra la flag.

La flag está en formato H4U{...}
