Análisis de Volcado de Memoria

Un equipo Windows ha sido comprometido. Se ha analizado el volcado de memoria con Volatility.
Identifica el proceso malicioso y extrae la flag.

La flag está en formato H4U{...}
