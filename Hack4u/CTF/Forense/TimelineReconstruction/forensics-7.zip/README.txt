Reconstrucción de Timeline de Ataque

Se ha producido una brecha de seguridad en la infraestructura corporativa.

Evidencias proporcionadas:
  - security_events.xml  : Eventos de seguridad de Windows
  - firewall.log         : Logs del firewall perimetral
  - ids_alerts.log       : Alertas del IDS (Suricata)
  - ir_report.txt        : Informe de respuesta a incidentes

Encuentra la flag.

La flag está en formato H4U{...}
