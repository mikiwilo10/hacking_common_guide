Análisis de Tráfico de Red

Se ha capturado tráfico de red sospechoso en la red corporativa.
Analiza el archivo .pcap y encuentra la flag.

La flag está en formato H4U{...}
