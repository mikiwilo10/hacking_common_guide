Análisis Forense de Email de Phishing

El SOC interceptó un email sospechoso dirigido al administrador del dominio.
Se sospecha que contiene un payload malicioso.

Analiza el archivo 'suspicious_email.eml' en profundidad y encuentra la flag.

La flag está en formato H4U{...}
