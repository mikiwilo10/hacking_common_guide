Tres archivos. Tres fragmentos. Una flag.
La flag está en formato H4U{...}
