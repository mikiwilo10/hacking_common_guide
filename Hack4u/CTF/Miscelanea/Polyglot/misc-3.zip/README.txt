Este archivo no es lo que parece.
Analízalo en profundidad.
La flag está en formato H4U{...}
