Decodifica el mensaje.
La flag está en formato H4U{...}
