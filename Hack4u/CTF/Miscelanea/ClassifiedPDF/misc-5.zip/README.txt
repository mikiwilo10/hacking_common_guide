Un documento PDF clasificado.
La información está fragmentada dentro de la estructura del PDF.
La flag está en formato H4U{...}
