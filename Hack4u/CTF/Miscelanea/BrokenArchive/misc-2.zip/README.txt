Un archivo fue dañado durante la transferencia.
Repáralo para acceder a su contenido.
La flag está en formato H4U{...}
