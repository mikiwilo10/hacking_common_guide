Se ha interceptado una transmisión de audio.
Analiza la señal para extraer el mensaje oculto.
La flag está en formato H4U{...}
