5000 líneas de logs. La flag está oculta entre el ruido.
La flag está en formato H4U{...}
