Ejecuta vault y conéctate al puerto 9001.
Encuentra el PIN y obtén la flag.
La flag está en formato H4U{...}
