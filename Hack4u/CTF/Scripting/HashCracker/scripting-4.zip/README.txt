Crakea los hashes para reconstruir la flag.
La flag está en formato H4U{...}
