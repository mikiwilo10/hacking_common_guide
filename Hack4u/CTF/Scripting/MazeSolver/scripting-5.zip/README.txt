Ejecuta maze_solver y conéctate al puerto 9005.
La flag está en formato H4U{...}
