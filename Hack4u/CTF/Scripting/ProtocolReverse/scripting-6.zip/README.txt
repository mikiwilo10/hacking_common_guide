Ejecuta protocol_server y conéctate al puerto 9006.
La flag está en formato H4U{...}
