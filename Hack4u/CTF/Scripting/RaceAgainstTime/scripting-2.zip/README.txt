Ejecuta speed_challenge y conéctate al puerto 9002.
La flag está en formato H4U{...}
